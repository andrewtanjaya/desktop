﻿using Microsoft.Win32;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UndertheSO
{
    /// <summary>
    /// Interaction logic for barcodeGenerator.xaml
    /// </summary>
    public partial class barcodeGenerator : Window
    {
        public barcodeGenerator()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog() { Filter = "JPEG|*.jpg", ValidateNames = true };
            {
                if(sfd.ShowDialog() == true)
                {
                    MessagingToolkit.QRCode.Codec.QRCodeEncoder encoder = new MessagingToolkit.QRCode.Codec.QRCodeEncoder();
                    encoder.QRCodeScale = 8;
                    Bitmap bmp = encoder.Encode(txtQR.Text);
                    bmp.Save(sfd.FileName,ImageFormat.Jpeg);
                }
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            SellTicket sell = new SellTicket();
            sell.Show();
            this.Close();
        }
    }
}
